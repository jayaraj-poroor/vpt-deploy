package org.rzo.yajsw.os.posix.bsd;

import org.rzo.yajsw.os.posix.PosixFileManager;

public class BSDFileManager extends PosixFileManager
{

}
