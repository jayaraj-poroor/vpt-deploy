package org.rzo.yajsw.os.posix.linux;

import org.rzo.yajsw.os.posix.PosixFileManager;

public class LinuxFileManager extends PosixFileManager
{

}
