package org.rzo.yajsw.os.posix.solaris;

import org.rzo.yajsw.os.posix.PosixFileManager;

public class SolarisFileManager extends PosixFileManager
{

}
