package org.rzo.yajsw.os.posix.linux;

import org.rzo.yajsw.os.posix.PosixProcess;

public class LinuxProcess extends PosixProcess
{

}
