#!/bin/bash 
java -jar VPTInstaller-2.0.jar $1 
