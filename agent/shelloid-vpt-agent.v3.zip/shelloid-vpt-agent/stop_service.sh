#!/bin/bash 
sh ./bin/stopDaemon.sh 
