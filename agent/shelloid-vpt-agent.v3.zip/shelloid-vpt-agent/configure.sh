#!/bin/bash 
cd vpt 
java -jar agent-3.0b.jar config 
