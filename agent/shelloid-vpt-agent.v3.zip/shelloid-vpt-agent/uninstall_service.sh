#!/bin/bash 
sh bin/uninstallDaemon.sh 
