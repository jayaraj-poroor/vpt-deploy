#!/bin/bash 
sh ./bin/startDaemon.sh 
