#!/bin/bash 
cd vpt 
java -jar agent-3.1.jar startWithGui 
